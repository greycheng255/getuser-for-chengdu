--
-- PostgreSQL database dump
--

\restrict 7Zqmy9LDL4QoWOejlO34XJbFCFtbHpuekgnVS1cIAWPgZeTmAYjfOP11dDsTy76

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_tasks; Type: TABLE; Schema: public; Owner: geo
--

CREATE TABLE public.ai_tasks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    plan_id integer,
    task_type character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    title character varying(255) NOT NULL,
    description text,
    input_data text,
    output_data text,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone,
    result_content text,
    keywords text
);


ALTER TABLE public.ai_tasks OWNER TO geo;

--
-- Name: ai_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: geo
--

CREATE SEQUENCE public.ai_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_tasks_id_seq OWNER TO geo;

--
-- Name: ai_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geo
--

ALTER SEQUENCE public.ai_tasks_id_seq OWNED BY public.ai_tasks.id;


--
-- Name: generation_history; Type: TABLE; Schema: public; Owner: geo
--

CREATE TABLE public.generation_history (
    id integer NOT NULL,
    user_id integer DEFAULT 1,
    title character varying(500) DEFAULT ''::character varying,
    brand_name character varying(255) DEFAULT ''::character varying,
    platform character varying(100) DEFAULT 'chatgpt'::character varying,
    outline_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.generation_history OWNER TO geo;

--
-- Name: generation_history_id_seq; Type: SEQUENCE; Schema: public; Owner: geo
--

CREATE SEQUENCE public.generation_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.generation_history_id_seq OWNER TO geo;

--
-- Name: generation_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geo
--

ALTER SEQUENCE public.generation_history_id_seq OWNED BY public.generation_history.id;


--
-- Name: geo_optimization_plan; Type: TABLE; Schema: public; Owner: geo
--

CREATE TABLE public.geo_optimization_plan (
    id integer NOT NULL,
    user_id integer,
    domain character varying(255) NOT NULL,
    brand_name character varying(255) NOT NULL,
    industry character varying(100) DEFAULT ''::character varying,
    location character varying(100) DEFAULT ''::character varying,
    keywords text,
    plan_data text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.geo_optimization_plan OWNER TO geo;

--
-- Name: geo_optimization_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: geo
--

CREATE SEQUENCE public.geo_optimization_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.geo_optimization_plan_id_seq OWNER TO geo;

--
-- Name: geo_optimization_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geo
--

ALTER SEQUENCE public.geo_optimization_plan_id_seq OWNED BY public.geo_optimization_plan.id;


--
-- Name: keyword_generation; Type: TABLE; Schema: public; Owner: geo
--

CREATE TABLE public.keyword_generation (
    id integer NOT NULL,
    user_id integer,
    brand_name character varying(255) NOT NULL,
    industry character varying(100) DEFAULT ''::character varying,
    location character varying(100) DEFAULT ''::character varying,
    generated_keywords text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.keyword_generation OWNER TO geo;

--
-- Name: keyword_generation_id_seq; Type: SEQUENCE; Schema: public; Owner: geo
--

CREATE SEQUENCE public.keyword_generation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.keyword_generation_id_seq OWNER TO geo;

--
-- Name: keyword_generation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geo
--

ALTER SEQUENCE public.keyword_generation_id_seq OWNED BY public.keyword_generation.id;


--
-- Name: platform_accounts; Type: TABLE; Schema: public; Owner: geo
--

CREATE TABLE public.platform_accounts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    platform character varying(50) NOT NULL,
    account_name character varying(255),
    cookies text,
    api_token text,
    refresh_token text,
    status character varying(20) DEFAULT 'active'::character varying,
    is_active boolean DEFAULT true,
    last_login_time timestamp without time zone,
    last_publish_time timestamp without time zone,
    cookie_expires_at timestamp without time zone,
    daily_limit integer DEFAULT 5,
    today_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.platform_accounts OWNER TO geo;

--
-- Name: platform_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: geo
--

CREATE SEQUENCE public.platform_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.platform_accounts_id_seq OWNER TO geo;

--
-- Name: platform_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geo
--

ALTER SEQUENCE public.platform_accounts_id_seq OWNED BY public.platform_accounts.id;


--
-- Name: platform_login_history; Type: TABLE; Schema: public; Owner: geo
--

CREATE TABLE public.platform_login_history (
    id integer NOT NULL,
    account_id integer,
    login_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    login_method character varying(50),
    ip_address character varying(100),
    user_agent text,
    success boolean,
    error_message text
);


ALTER TABLE public.platform_login_history OWNER TO geo;

--
-- Name: platform_login_history_id_seq; Type: SEQUENCE; Schema: public; Owner: geo
--

CREATE SEQUENCE public.platform_login_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.platform_login_history_id_seq OWNER TO geo;

--
-- Name: platform_login_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geo
--

ALTER SEQUENCE public.platform_login_history_id_seq OWNED BY public.platform_login_history.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: geo
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255) DEFAULT ''::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone
);


ALTER TABLE public.users OWNER TO geo;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: geo
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO geo;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geo
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: website_diagnosis; Type: TABLE; Schema: public; Owner: geo
--

CREATE TABLE public.website_diagnosis (
    id integer NOT NULL,
    user_id integer,
    domain character varying(255) NOT NULL,
    url character varying(500) NOT NULL,
    brand_name character varying(255) DEFAULT ''::character varying,
    overall_score numeric(5,2) DEFAULT 0,
    content_score numeric(5,2) DEFAULT 0,
    structure_score numeric(5,2) DEFAULT 0,
    authority_score numeric(5,2) DEFAULT 0,
    technical_score numeric(5,2) DEFAULT 0,
    issues_count integer DEFAULT 0,
    issues text,
    suggestions text,
    diagnosis_result text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.website_diagnosis OWNER TO geo;

--
-- Name: website_diagnosis_id_seq; Type: SEQUENCE; Schema: public; Owner: geo
--

CREATE SEQUENCE public.website_diagnosis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.website_diagnosis_id_seq OWNER TO geo;

--
-- Name: website_diagnosis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geo
--

ALTER SEQUENCE public.website_diagnosis_id_seq OWNED BY public.website_diagnosis.id;


--
-- Name: ai_tasks id; Type: DEFAULT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.ai_tasks ALTER COLUMN id SET DEFAULT nextval('public.ai_tasks_id_seq'::regclass);


--
-- Name: generation_history id; Type: DEFAULT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.generation_history ALTER COLUMN id SET DEFAULT nextval('public.generation_history_id_seq'::regclass);


--
-- Name: geo_optimization_plan id; Type: DEFAULT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.geo_optimization_plan ALTER COLUMN id SET DEFAULT nextval('public.geo_optimization_plan_id_seq'::regclass);


--
-- Name: keyword_generation id; Type: DEFAULT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.keyword_generation ALTER COLUMN id SET DEFAULT nextval('public.keyword_generation_id_seq'::regclass);


--
-- Name: platform_accounts id; Type: DEFAULT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.platform_accounts ALTER COLUMN id SET DEFAULT nextval('public.platform_accounts_id_seq'::regclass);


--
-- Name: platform_login_history id; Type: DEFAULT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.platform_login_history ALTER COLUMN id SET DEFAULT nextval('public.platform_login_history_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: website_diagnosis id; Type: DEFAULT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.website_diagnosis ALTER COLUMN id SET DEFAULT nextval('public.website_diagnosis_id_seq'::regclass);


--
-- Data for Name: ai_tasks; Type: TABLE DATA; Schema: public; Owner: geo
--

COPY public.ai_tasks (id, user_id, plan_id, task_type, status, title, description, input_data, output_data, error_message, created_at, updated_at, completed_at, result_content, keywords) FROM stdin;
\.


--
-- Data for Name: generation_history; Type: TABLE DATA; Schema: public; Owner: geo
--

COPY public.generation_history (id, user_id, title, brand_name, platform, outline_count, created_at) FROM stdin;
\.


--
-- Data for Name: geo_optimization_plan; Type: TABLE DATA; Schema: public; Owner: geo
--

COPY public.geo_optimization_plan (id, user_id, domain, brand_name, industry, location, keywords, plan_data, created_at) FROM stdin;
\.


--
-- Data for Name: keyword_generation; Type: TABLE DATA; Schema: public; Owner: geo
--

COPY public.keyword_generation (id, user_id, brand_name, industry, location, generated_keywords, created_at) FROM stdin;
\.


--
-- Data for Name: platform_accounts; Type: TABLE DATA; Schema: public; Owner: geo
--

COPY public.platform_accounts (id, user_id, platform, account_name, cookies, api_token, refresh_token, status, is_active, last_login_time, last_publish_time, cookie_expires_at, daily_limit, today_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_login_history; Type: TABLE DATA; Schema: public; Owner: geo
--

COPY public.platform_login_history (id, account_id, login_time, login_method, ip_address, user_agent, success, error_message) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: geo
--

COPY public.users (id, username, password, email, created_at, last_login) FROM stdin;
\.


--
-- Data for Name: website_diagnosis; Type: TABLE DATA; Schema: public; Owner: geo
--

COPY public.website_diagnosis (id, user_id, domain, url, brand_name, overall_score, content_score, structure_score, authority_score, technical_score, issues_count, issues, suggestions, diagnosis_result, created_at) FROM stdin;
\.


--
-- Name: ai_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geo
--

SELECT pg_catalog.setval('public.ai_tasks_id_seq', 1, false);


--
-- Name: generation_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geo
--

SELECT pg_catalog.setval('public.generation_history_id_seq', 1, false);


--
-- Name: geo_optimization_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geo
--

SELECT pg_catalog.setval('public.geo_optimization_plan_id_seq', 1, false);


--
-- Name: keyword_generation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geo
--

SELECT pg_catalog.setval('public.keyword_generation_id_seq', 1, false);


--
-- Name: platform_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geo
--

SELECT pg_catalog.setval('public.platform_accounts_id_seq', 1, false);


--
-- Name: platform_login_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geo
--

SELECT pg_catalog.setval('public.platform_login_history_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geo
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: website_diagnosis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geo
--

SELECT pg_catalog.setval('public.website_diagnosis_id_seq', 1, false);


--
-- Name: ai_tasks ai_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.ai_tasks
    ADD CONSTRAINT ai_tasks_pkey PRIMARY KEY (id);


--
-- Name: generation_history generation_history_pkey; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.generation_history
    ADD CONSTRAINT generation_history_pkey PRIMARY KEY (id);


--
-- Name: geo_optimization_plan geo_optimization_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.geo_optimization_plan
    ADD CONSTRAINT geo_optimization_plan_pkey PRIMARY KEY (id);


--
-- Name: keyword_generation keyword_generation_pkey; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.keyword_generation
    ADD CONSTRAINT keyword_generation_pkey PRIMARY KEY (id);


--
-- Name: platform_accounts platform_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.platform_accounts
    ADD CONSTRAINT platform_accounts_pkey PRIMARY KEY (id);


--
-- Name: platform_accounts platform_accounts_user_id_platform_key; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.platform_accounts
    ADD CONSTRAINT platform_accounts_user_id_platform_key UNIQUE (user_id, platform);


--
-- Name: platform_login_history platform_login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.platform_login_history
    ADD CONSTRAINT platform_login_history_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: website_diagnosis website_diagnosis_pkey; Type: CONSTRAINT; Schema: public; Owner: geo
--

ALTER TABLE ONLY public.website_diagnosis
    ADD CONSTRAINT website_diagnosis_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_tasks_created_at; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_ai_tasks_created_at ON public.ai_tasks USING btree (created_at);


--
-- Name: idx_ai_tasks_plan_id; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_ai_tasks_plan_id ON public.ai_tasks USING btree (plan_id);


--
-- Name: idx_ai_tasks_status; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_ai_tasks_status ON public.ai_tasks USING btree (status);


--
-- Name: idx_ai_tasks_user_id; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_ai_tasks_user_id ON public.ai_tasks USING btree (user_id);


--
-- Name: idx_diagnosis_created_at; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_diagnosis_created_at ON public.website_diagnosis USING btree (created_at);


--
-- Name: idx_diagnosis_domain; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_diagnosis_domain ON public.website_diagnosis USING btree (domain);


--
-- Name: idx_diagnosis_user_id; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_diagnosis_user_id ON public.website_diagnosis USING btree (user_id);


--
-- Name: idx_generation_created_at; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_generation_created_at ON public.generation_history USING btree (created_at);


--
-- Name: idx_generation_user_id; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_generation_user_id ON public.generation_history USING btree (user_id);


--
-- Name: idx_keyword_brand_name; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_keyword_brand_name ON public.keyword_generation USING btree (brand_name);


--
-- Name: idx_keyword_created_at; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_keyword_created_at ON public.keyword_generation USING btree (created_at);


--
-- Name: idx_keyword_user_id; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_keyword_user_id ON public.keyword_generation USING btree (user_id);


--
-- Name: idx_plan_brand_name; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_plan_brand_name ON public.geo_optimization_plan USING btree (brand_name);


--
-- Name: idx_plan_created_at; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_plan_created_at ON public.geo_optimization_plan USING btree (created_at);


--
-- Name: idx_plan_domain; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_plan_domain ON public.geo_optimization_plan USING btree (domain);


--
-- Name: idx_plan_user_id; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_plan_user_id ON public.geo_optimization_plan USING btree (user_id);


--
-- Name: idx_platform_accounts_platform; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_platform_accounts_platform ON public.platform_accounts USING btree (platform);


--
-- Name: idx_platform_accounts_user_id; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_platform_accounts_user_id ON public.platform_accounts USING btree (user_id);


--
-- Name: idx_platform_login_history_account_id; Type: INDEX; Schema: public; Owner: geo
--

CREATE INDEX idx_platform_login_history_account_id ON public.platform_login_history USING btree (account_id);


--
-- PostgreSQL database dump complete
--

\unrestrict 7Zqmy9LDL4QoWOejlO34XJbFCFtbHpuekgnVS1cIAWPgZeTmAYjfOP11dDsTy76

